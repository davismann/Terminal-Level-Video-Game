------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: g++ -std=c++17 ActionDriver.cpp Inventory.cpp Status.cpp Party.cpp Sorcerer.cpp Map.cpp
Run: ./proj3
------------------------
DEPENDENCIES
------------------------
Inventory.h, Status.h, Party.h, Sorcerer.cpp and Map.cpp Sorcerer.h must be in the same directory as the cpp 
files in order to compile.
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Fall 2022 Project 3
Authors: Davis Mann, David Camargo
Recitations: 302, 123 – Michelle Ramsahoye, Christopher Ojukwu
Date: Dec 1, 2022
------------------------
ABOUT THIS PROJECT
------------------------
This project is developing an interactive video game that allows a user to choose their own journey. 
We decided to start this project by creating all the header files necessary to make the video game. 
The game we made is similar to Dungeons and Dragons. There are multiple options within the game.
You can fight monsters, trade with merchants, explore rooms, etc.
This was the first game we have ever created and hope that the user will love it!
Thank you and have fun playing!