// CSCI 1300 Fall 2022
// Author: Davis Mann, David Camargo
// Recitation: 302, 123 – Michelle Ramsahoye, Christopher Ojukwu
// Project 3 - GameEnd.h

#include <iostream>
#include <cassert>
#include <string>
#include <vector>
#include <cctype>

using namespace std;

class GameEnd
{
    public:
        void winGame(string filename);
        void loseToSorc(string filename);
        void deathByHungAll(string filname);
        void giveUp(string filename);
};
