// CSCI 1300 Fall 2022
// Author: Davis Mann, David Camargo
// Recitation: 302, 123 – Michelle Ramsahoye, Christopher Ojukwu
// Project 3 - Status.h

#include <iostream>
#include <cassert>
#include <string>
#include <vector>
#include <cctype>

#ifndef STATUS_h
#define STATUS_H

using namespace std;

class Status
{
    private:
        int rooms;
        int keys;
        int anger;
        const int tot_rooms = 5;

    public:
        Status();
        int getRooms();
        void addRooms();
        int getKeys();
        void addKeys();
        int getAnger();
        void addAnger();

        void randKey();

};

#endif