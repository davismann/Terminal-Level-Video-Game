// CSCI 1300 Fall 2022
// Author: Davis Mann, David Camargo
// Recitation: 302, 123 – Michelle Ramsahoye, Christopher Ojukwu
// Project 3 - Status.cpp

#include <iostream>
#include <cassert>
#include <string>
#include <vector>
#include <cctype>
#include "Status.h"

using namespace std;

Status::Status()
{
    rooms = 0;
    keys = 0;
    anger = 0;
}

int Status::getRooms()
{
    return rooms;
}

void Status::addRooms()
{
    rooms++;
}

int Status::getKeys()
{
    return keys;
}

void Status::addKeys()
{
    keys++;
}
int Status::getAnger()
{
    return anger;
}

void Status::addAnger()
{
    anger++;
}

void Status::randKey()
{
    //10% chance that key is added
}


