// CSCI 1300 Fall 2022
// Author: Davis Mann, David Camargo
// Recitation: 302, 123 – Michelle Ramsahoye, Christopher Ojukwu
// Project 3 - Party.h

#include <iostream>
#include <cassert>
#include <string>
#include <vector>
#include <cctype>

#ifndef PARTY_h
#define PARTY_H

using namespace std;

class Party
{
    private:
        int fullness;
                
    public:
        Party();
        void setFullness(int fullness_);
        int getFullness();
        
        void move();
        void inve();
        void fight();
        int poison();
        int locked();

        
};

#endif