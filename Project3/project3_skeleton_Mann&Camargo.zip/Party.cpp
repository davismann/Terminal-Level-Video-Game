// CSCI 1300 Fall 2022
// Author: Davis Mann, David Camargo
// Recitation: 302, 123 – Michelle Ramsahoye, Christopher Ojukwu
// Project 3 - Party.cpp

#include <iostream>
#include <cassert>
#include <string>
#include <vector>
#include <cctype>
#include "Party.h"

using namespace std;

Party::Party()
{
    fullness = 50;
}

void Party::setFullness(int fullness_)
{
    if((fullness_<=50)&&(fullness_>0))
    {
        fullness = fullness_;
    }
    else if(fullness_ == 0)
    {
        fullness = fullness_;
    }
}

int Party::getFullness()
{
    if(fullness == 0)
    {
        return -1; //Party member has died.
    }
    else
    {
        return fullness;
    }
}


void Party::move()
{
    //Everytime the user moves there is a 20% chance that the 
    // members of the party lose 1 point of fullness
}

void Party::inve()
{
    //Everytime the user investigates all the party members have a 50% chance
    // that they lose 1 point of fullness
}

void Party::fight()
{
    //After every fight there is a 50% chance party members lose 1 point of fullness
}

int Party::poison()
{
    //If party member gets poisend they lose 10 fullness points
    // If party member fullness reaches 0 then return -1 (Check for negative one after to kill of party member)
}

int Party::locked()
{
    //Random party member gets chosen and is left behind.
    //Return an index of which party member gets left behind (Kill them off after)
}