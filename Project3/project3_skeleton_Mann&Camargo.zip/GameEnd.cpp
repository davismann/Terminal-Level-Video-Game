// CSCI 1300 Fall 2022
// Author: Davis Mann, David Camargo
// Recitation: 302, 123 – Michelle Ramsahoye, Christopher Ojukwu
// Project 3 - GameEnd.cpp

#include <iostream>
#include <cassert>
#include <string>
#include <vector>
#include <cctype>
#include "GameEnd.h"

using namespace std;

void GameEnd::winGame(string filename)
{
    // If getRoom is equal to 5 the game is over and the team has won
    // If atleast one team member plus the main member are still alive when 5 rooms have been reached, game has been won
    // Print message congratulating the player on their success
    // Print the final game stats
    // Save stats into the filename
}
void GameEnd::loseToSorc(string filename)
{
    // If sorcer anger level is 100, sorcer destroys all players
    // Print a message informing the tragic event that caused the loss
    // Print the final game stats
    // Save stats into the filename
}
void GameEnd::deathByHungAll(string filename)
{
    // If the party leader dies from hunger (party vector is empty) then they lose immediately and the game ends
    // Print a message informing the tragic event that caused the loss
    // Print the final game stats
    // Save stats into the filename
}
void GameEnd::giveUp(string filename)
{
    // If user chooses the option to give up after every time they move
    // Print a message informing the tragic event that caused the loss
    // Print the final game stats
    // Save stats into the filename
}
