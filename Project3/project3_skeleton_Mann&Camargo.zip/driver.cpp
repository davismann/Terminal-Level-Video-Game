// CSCI 1300 Fall 2022
// Author: Davis Mann, David Camargo
// Recitation: 302, 123 – Michelle Ramsahoye, Christopher Ojukwu
// Project 3 - driver.cpp

#include <iostream>
#include <cassert>
#include <string>
#include <vector>
#include <cctype>
#include "GameEnd.h"
#include "Inventory.h"
#include "Party.h"
#include "Status.h"

using namespace std;

int main(){

// Test for Inventory
Inventory Test1;
Test1.setGold(20);
assert((Test1.getGold()) == 120);
Test1.setIngred(50);
assert((Test1.getIngred()) == 50);
Test1.setCookAt(13, 2);
assert((Test1.getCookAt(2)) == 13);
Test1.setWeaponsAt(2, 4);
assert((Test1.getWeaponsAt(4)) == 2);
Test1.setArmor(43);
assert((Test1.getArmor()) == 43);
Test1.setTresAt(1, 1);
assert((Test1.getTresAt(1)) == 1);
assert((Test1.weaponDamage()) == 10);

// Test for Party
Party Test2 = Party();
assert(Test2.getFullness()==50);
Test2.setFullness(60);
assert(Test2.getFullness()==50);
Test2.setFullness(25);
assert(Test2.getFullness()==25);

//Test for Status
Status Test3 = Status();
assert(Test3.getAnger()==0);
assert(Test3.getKeys()==0);
assert(Test3.getRooms()==0);
for(int i=0; i<5; i++)
{
    Test3.addAnger();
    Test3.addRooms();
    Test3.addKeys();
}
assert(Test3.getAnger()==5);
assert(Test3.getKeys()==5);
assert(Test3.getRooms()==5);

return 0;
}
