// CSCI 1300 Fall 2022
// Author: Davis Mann, David Camargo
// Recitation: 302, 123 – Michelle Ramsahoye, Christopher Ojukwu
// Project 3 - Inventory.cpp

#include <iostream>
#include <cassert>
#include <string>
#include <vector>
#include <cctype>
#include "Inventory.h"

using namespace std;

        Inventory::Inventory()
        {
            gold = 100;
            ingred = 0;
            armor = 0;
            for (int i = 0; i < 5; i++)
            {
                cook[i] = 0;
            }
            for (int i = 0; i < 5; i++)
            {
                weapons[i] = 0;
                tres[i] = 0;
            }
        }
        void Inventory::setGold(int gold_)
        {
            gold += gold_;
        }
        int Inventory::getGold()
        {
            return gold;
        }
        void Inventory::setIngred(int ingred_)
        {
            ingred = ingred_;
        }
        int Inventory::getIngred()
        {
            return ingred;
        }
        void Inventory::setCookAt(int cook_, int index)
        {
            if ((index >= 0) && (index < 3))
            {
                cook[index] = cook_;
            }
        }
        int Inventory::getCookAt(int index)
        {
            if ((index >= 0) && (index < 3))
            {
               return cook[index];
            }
        }
        void Inventory::setWeaponsAt(int weapons_, int index)
        {
            if ((index >= 0) && (index < 5))
            {
                weapons[index] = weapons_;
            }
        }
        int Inventory::getWeaponsAt(int index)
        {
            if ((index >= 0) && (index < 5))
            {
               return weapons[index];
            }
        }
        void Inventory::setArmor(int armor_)
        {
            armor = armor_;
        }
        int Inventory::getArmor()
        {
            return armor;
        }
        void Inventory::setTresAt(int tres_, int index)
        {
            if ((index >= 0) && (index < 5))
            {
                tres[index] = tres_;
            }
        }
        int Inventory::getTresAt(int index)
        {
            if ((index >= 0) && (index < 5))
            {
                return tres[index];
            }
        }

        int Inventory::weaponDamage()
        {
            int amountWeap = 0;
            for (int i = 0; i < 5; i++)
            {
                amountWeap += weapons[i];
            }

            int strength = 5*(amountWeap) + 1*(weapons[2]) + 2*(weapons[3]);
            return strength;
        }
        int Inventory::cookDamage(int cook[], int index)
        {
            // User choices which cookware to use
            // Depending one which cookware was selected to use
            // Each cookware has a probability of breaking: Pan = 25%, Pot = 10%, Cauldron = 2%
            // Return if the cookware breaks
            // Lose ingredients used to make and remove the cookware from inventory
        }
        void Inventory::sellTres()
        {
            // User can sell items once they encounter a merchant.

            // 1 Room: Silver ring (R) - 10 gold pieces each
            // 2 Rooms: Ruby necklace (N) - 20 gold pieces each
            // 3 Rooms: Emerald bracelet (B) - 30 gold pieces each
            // 4 Rooms: Diamond circlet (C) - 40 gold pieces each
            // 5 Rooms: Gem-encrusted goblet (G) - 50 gold pieces each

            // Once treasure is sold remove the treasure from inventory and add the gold obtained to the total amount of gold in inventory.
        }
        void Inventory::randRob()
        {
            // Team gets robbed
            // Randomly lose 10kg of ingredients, 1 cookware item, 1 armor item
            // Print message
        }
        void Inventory::randBreak()
        {
            // One weapons or armor breaks
            // Print message
        }
